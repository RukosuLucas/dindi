-- ==========================================================
-- DINDI — PREPARAÇÃO PARA A SINCRONIZAÇÃO  (migração 002)
-- Execute no Supabase: SQL Editor > New query > cole tudo > Run.
-- Ordem: depois do SQL inicial e do dindi_auth.sql (001).
-- Seguro rodar mais de uma vez. NÃO apaga nem altera dados.
--
-- Por que não há tabelas novas: as 8 tabelas atuais já cobrem tudo
-- (transações, dívidas, metas, viagens, despesas de viagem, compras,
-- preferências e perfil). Só faltava um campo e garantir as permissões.
-- ==========================================================

-- 1) SALDO INICIAL: o app usa esse valor em todos os cálculos
--    (projeção e fechamento mês a mês) e hoje não havia onde guardá-lo.
ALTER TABLE public.user_preferences
    ADD COLUMN IF NOT EXISTS initial_balance NUMERIC(14,2) NOT NULL DEFAULT 0;

-- 2) PERMISSÕES DA API: o app logado (role "authenticated") precisa poder
--    ler e gravar. A segurança continua sendo o RLS: cada usuário só
--    enxerga e altera as próprias linhas. O visitante sem login (anon)
--    não recebe acesso nenhum às tabelas.
GRANT SELECT, INSERT, UPDATE, DELETE ON
    public.profiles,
    public.user_preferences,
    public.financial_transactions,
    public.debts,
    public.savings_goals,
    public.trips,
    public.trip_expenses,
    public.shopping_items
TO authenticated;

REVOKE ALL ON
    public.profiles,
    public.user_preferences,
    public.financial_transactions,
    public.debts,
    public.savings_goals,
    public.trips,
    public.trip_expenses,
    public.shopping_items
FROM anon;

-- ==========================================================
-- OPCIONAL (descomente só se fizer sentido para você)
-- A planilha não trazia data para "Gás Dez.", então ele foi importado
-- sem data e o fechamento mensal o conta no mês atual. Se ele vence em
-- dezembro, ajuste a data (troque o dia e o usuário):
-- ==========================================================
-- UPDATE public.financial_transactions
--    SET transaction_date = '2026-12-15'
--  WHERE description = 'Gás Dez.'
--    AND notes LIKE '%[import-planilha-nov2026]%'
--    AND user_id = (SELECT id FROM public.profiles WHERE username = 'SEU_USUARIO');
